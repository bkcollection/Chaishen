angular.module('Chaishen.directives', [])



;
